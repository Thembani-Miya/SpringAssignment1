package com.example.springassignment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springassignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
