package com.example.springassignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springassignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springassignment1Application.class, args);
	}

}
